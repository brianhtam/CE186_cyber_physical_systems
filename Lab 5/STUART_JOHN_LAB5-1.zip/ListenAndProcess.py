"""
    ListenAndProcess
    John Stuart
    Retrieves data from the wallflower server, processes it, and sends results
    back to server
"""
# added sys.path block due to python error in finding correct file path
# import serial, json, and requests to read and send data to arduino and server
import sys  
sys.path.append(r'C:\Python27\Lib\site-packages')
import serial

sys.path.append(r'C:\Python27\Lib')
import json

sys.path.append(r'C:\Python27\Lib\site-packages\pip\_vendor')
import requests 

import time
import datetime



delay = 5 # Delay in seconds

base = 'http://127.0.0.1:5000'
network_id = 'local'
header = {}




###### SERVER communication functions ##########


def storeresults(results, t):


    endpoint = '/networks/local/objects/result-object/streams/result-stream/points'
    print results["Health Level"]
    query = {
        'points-value': results["Health Level"],
        'points-at': t
    }
                   
    response = requests.request('POST', base + endpoint, params=query, headers=header, timeout=120 )
    resp = json.loads( response.text )
    print resp
    if resp['points-code'] == 200:
        print( 'Update result-stream points: ok')
    else:
        print( 'Update result-stream points: error')
        print( response.text )



def loop(timeL,tLE,tT,rN,resultsLast):
    # Retrieve (GET) data from the server
    # Set url address.
    #base = 'http://127.0.0.1:5000'
    try:
        endpoint = '/networks/local/objects/pho-object/streams/pho-stream/points'
        query = {}
        response = requests.request('GET', base + endpoint, params=query, headers=header, timeout=120 )
        resp = json.loads( response.text )
        if resp['points-code'] == 200:
            print( 'Receive pho-stream points: ok')
            print resp['points'][0]['value'] 
            phoIN = resp['points'][0]['value'] 
            t= resp['points'][0]['at']
            #if t == timeL:
            #    print ("no new data found")
            #    time.sleep(1) 
            #    print "here5.11"
            #    return resultsLast
        else:
            print( 'Receive pho-stream points: error')
            print( response.text )
            
            
        #store temperature points  
        endpoint = '/networks/local/objects/temp-object/streams/temp-stream/points'
        query = {}
        response = requests.request('GET', base + endpoint, params=query, headers=header, timeout=120 )
        resp = json.loads( response.text )
        if resp['points-code'] == 200:
            print( 'Recieve temp-stream points: ok')
            tempIN = resp['points'][0]['value']
        else:
            print( 'Recieve temp-stream points: error')
            print( response.text )     
        
    except:
        print ("retreival failed")    
    time.sleep(1) 
    ##### process data ######
    try:
        #process the results. total exposure = sum of light levels retrieved
        readingNo = rN + 1
        totalLightExposure = tLE + phoIN
        avgLightExposure = totalLightExposure/readingNo
        totalTemp = tT + tempIN
        avgTemp = totalTemp/readingNo
        if phoIN < 45:
            if tempIN <= 25:
                healthLevel = 1
                rec = "Healthy conditions, no recommendation"
            elif tempIN > 25 & tempIN <= 27:
                healthLevel = 2
                rec = "Temperature is high, consider turning down the thermostat"
            else:
                healthLevel = 3
                rec = "Heat stroke imminent, activating fan"
        else:
            if tempIN <= 19:
                healthLevel = 1
                rec = "It's a bit bright, healthy but electric lights are unneeded"
            elif tempIN > 20 & tempIN <= 21:
                healthLevel = 2
                rec = "Temperature and light high, consider closing the blinds to avoid solar gain"
            else:
                healthLevel = 3
                rec = "Heat stroke imminent, activating automatic blinds and fan"
                
        print ("Health Level = "), healthLevel
        print ("Reading # = "), readingNo
        print ("Total Light Exposure = "), totalLightExposure
        print ("Average Light Exposure = "), avgLightExposure
        print rec
        
        results = {"t":t,"Rec":rec,"Health Level":healthLevel,
                   "Total Light Exposure":totalLightExposure,
                   "Total Temp": totalTemp,
                   "Average Light Exposure":avgLightExposure,
                   "Average Temp":avgTemp,
                   "Reading Number":readingNo
        }
        
        #collect data every 5 seconds
        time.sleep(5) 
        return results
    except:
        print("processing failed")    
    time.sleep(1) 
###### POST and structure functions ##########

# Run once at the start
def setup():
    try:
        print "Setup"
    except:
        print "Setup Error"




# Run continuously forever
# with a delay between calls
def delayed_loop():
    print "Delayed Loop"

#Run once at the end 
def close(): 
    try: 
        print "Close ListenAndProcess" 
        #ser.close() 
    except: 
        print "Close Error"
    


###### MAIN function ##########
  
def main():
    # Call setup function
    setup()
    # Set start time
    nextLoop = time.time()
    readingNo = 0
    totalLightExposure = 0
    totalTemp = 0
    tLast=0
    resultsLast = {"t":0,"Rec":0,"Health Level":0,
               "Total Light Exposure":0,
               "Total Temp": 0,
               "Average Light Exposure":0,
               "Average Temp":0,
               "Reading Number":0
    }
    t=0
    time.sleep(1) 
    
    while(True):
        # Try loop() and delayed_loop()
        try:
            results = loop(t,totalLightExposure,totalTemp,readingNo,resultsLast)
            totalLightExposure = results["Total Light Exposure"]
            totalTemp = results["Total Temp"]
            readingNo = results["Reading Number"]
            t = results["t"]
            if t != tLast:
                print ("Sending Results: ") 
                print results
                storeresults (results, t)
                tLast = t
                print tLast
            else:
                print("no results to store")
            if time.time() > nextLoop:
                # If next loop time has passed...
                nextLoop = time.time() + delay
                delayed_loop()                
        except KeyboardInterrupt:
            # If user enters "Ctrl + C", break while loop
            break
        except:
            # Catch all errors
            print "Unexpected error."
    # Call close function
#    close()

# Run the program
#####NOTE: dont forget to restart the consoles if the server crashes.
#otherwise I'll get errors
main()
