"""
    ListenAndSend
    John Stuart
    Reads temperature and light level data from the arduino and posts that data 
    to a data stream on wallflower. Checks server for results and sends
    retrieved health level to arduino to actuate LED to 3 brightness levels
    (LED = off, medium, or high).
"""
# added sys.path block due to python error in finding correct file path
# import serial, json, and requests to read and send data to arduino and server
import sys  
sys.path.append(r'C:\Python27\Lib\site-packages')
import serial

sys.path.append(r'C:\Python27\Lib')
import json

sys.path.append(r'C:\Python27\Lib\site-packages\pip\_vendor')
import urllib3
import requests 

import time
import datetime




# Change the port name to match the port 
# to which your Arduino is connected. 
serial_port_name = 'COM3' # for Windows 
ser = serial.Serial(serial_port_name, 9600, timeout=1) 

delay = 5 # Delay in seconds

base = 'http://127.0.0.1:5000'
network_id = 'local'
header = {}

#### Delete existing objects ####
#deletes temperature and pho objects

try:
    
    query = {
            'object-name': 'temp-object'
    }
    endpoint = '/networks/'+network_id+'/objects/temp-object'
    response = requests.request('DELETE', base + endpoint, params=query, headers=header, timeout=120 )
    resp = json.loads( response.text )
    if resp['object-code'] == 201:
        print('Create object temp-object: ok')
    else:
        print('Create object temp-object: error')
        print( response.text )
    
    query = {
        'object-name': 'pho-object'
    }
    endpoint = '/networks/'+network_id+'/objects/pho-object'
    response = requests.request('DELETE', base + endpoint, params=query, headers=header, timeout=120 )
    resp = json.loads( response.text )
    if resp['object-code'] == 201:
        print('Create object pho-object: ok')
    else:
        print('Create object pho-object: error')
        print( response.text )
    
    query = {
        'object-name': 'result-object'
    }
    endpoint = '/networks/'+network_id+'/objects/result-object'
    response = requests.request('DELETE', base + endpoint, params=query, headers=header, timeout=120 )
    resp = json.loads( response.text )
    if resp['object-code'] == 201:
        print('Create object result-object: ok')
    else:
        print('Create object result-object: error')
        print( response.text )
except:
    print ("nothing to delete")    




#### Create objects ####
#creates temperature object
query = {   
        'object-name': 'temp-object'
}
endpoint = '/networks/'+network_id+'/objects/temp-object'
response = requests.request('PUT', base + endpoint, params=query, headers=header, timeout=120 )
resp = json.loads( response.text )
if resp['object-code'] == 201:
    print('Create object temp-object: ok')
else:
    print('Create object temp-object: error')
    print( response.text )
    
#creates temperature stream    
query = {
    'stream-name': 'temp-stream',
    'points-type': 'i' # 'i', 'f', or 's'
}
endpoint = '/networks/'+network_id+'/objects/temp-object/streams/temp-stream'
response = requests.request('PUT', base + endpoint, params=query, headers=header, timeout=120 )
resp = json.loads( response.text )
if resp['stream-code'] == 201:
    print('Create stream temp-stream: ok')
else:
    print('Create stream temp-stream: error')
    print( response.text )
    
    
#creates light level object
query = {
    'object-name': 'pho-object'
}
endpoint = '/networks/'+network_id+'/objects/pho-object'
response = requests.request('PUT', base + endpoint, params=query, headers=header, timeout=120 )
resp = json.loads( response.text )
if resp['object-code'] == 201:
    print('Create object pho-object: ok')
else:
    print('Create object pho-object: error')
    print( response.text )
    
#creates light level stream    
query = {
    'stream-name': 'pho-stream',
    'points-type': 'i' # 'i', 'f', or 's'
}
endpoint = '/networks/'+network_id+'/objects/pho-object/streams/pho-stream'
response = requests.request('PUT', base + endpoint, params=query, headers=header, timeout=120 )
resp = json.loads( response.text )
if resp['stream-code'] == 201:
    print('Create stream pho-stream: ok')
else:
    print('Create stream pho-stream: error')
    print( response.text )  
    
    
#creates result object
query = {   
        'object-name': 'result-object'
}
endpoint = '/networks/'+network_id+'/objects/result-object'
response = requests.request('PUT', base + endpoint, params=query, headers=header, timeout=120 )
resp = json.loads( response.text )
if resp['object-code'] == 201:
    print('Create object result-object: ok')
else:
    print('Create object result-object: error')
    print( response.text )
    
#creates result stream    
query = {
    'stream-name': 'result-stream',
    'points-type': 'i' # 'i', 'f', or 's'
}
endpoint = '/networks/'+network_id+'/objects/result-object/streams/result-stream'
response = requests.request('PUT', base + endpoint, params=query, headers=header, timeout=120 )
resp = json.loads( response.text )
if resp['stream-code'] == 201:
    print('Create stream result-stream: ok')
else:
    print('Create stream result-stream: error')
    print( response.text )    







###### SERVER communication functions ##########
#actual sending function





def storedata():


    # Set body (also referred to as data or payload). Body is a JSON string.
    #store light level points
    endpoint = '/networks/local/objects/pho-object/streams/pho-stream/points'
    query = {
            'points-value': Pho,
            'points-at': t
    }
    response = requests.request('POST', base + endpoint, params=query, headers=header, timeout=120 )
    resp = json.loads( response.text )
    if resp['points-code'] == 200:
        print( 'Update test-stream points: ok')
    else:
        print( 'Update test-stream points: error')
        print( response.text )
        
        
    #store temperature points  
    endpoint = '/networks/local/objects/temp-object/streams/temp-stream/points'
    query = {
        'points-value': Temp,
        'points-at': t
    }
    response = requests.request('POST', base + endpoint, params=query, headers=header, timeout=120 )
    resp = json.loads( response.text )
    if resp['points-code'] == 200:
        print( 'Update test-stream points: ok')
    else:
        print( 'Update test-stream points: error')
        print( response.text )        
        
        
        
    time.sleep(1)
    
    print Pho
    print Temp
    
    time.sleep(1)



# Retrieve the health level results from the server
def retrieveresults():
    # Retrieve (GET) names from the NameServer

    query = {}
    endpoint = '/networks/local/objects/result-object/streams/result-stream/points'
    address = base + endpoint
    
    # Form and send request. Set timeout to 2 minutes. Receive response.
    response = requests.request('GET', address, timeout=120 )

    # Text is JSON string. Convert to Python dictionary/list
    response = json.loads( response.text )
    hLev = response['Health Level']
    print hLev
    return hLev
    

    
    


###### ARDUINO communication functions ##########

# Run once at the start
def setup():
    try:
        print 'Setup'
    except:
        print 'Setup Error'


# Run continuously forever 
def loop(): 
    # Check if something is in serial buffer 
    if ser.inWaiting() > 0: 
        try: 
            # Read entire line 
            # (until '\n') 
            x = ser.readline()
            #print x, type(x)
            dType = x[0]
            if dType == 'L':
                Pho = int(ser.readline())
                print "Recieved Lux:", Pho, type(Pho)
                dType == ser.readline()
                Temp = int(ser.readline())
                print "Recieved Temp:", Temp, type(Temp)
                t =  datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

                
                #### Post received data to server ####
                #store light level points
                endpoint = '/networks/local/objects/pho-object/streams/pho-stream/points'
                query = {
                        'points-value': Pho,
                        'points-at': t
                }
                response = requests.request('POST', base + endpoint, params=query, headers=header, timeout=120 )
                resp = json.loads( response.text )
                if resp['points-code'] == 200:
                    print( 'Update test-stream points: ok')
                else:
                    print( 'Update test-stream points: error')
                    print( response.text )
                    
                    
                #store temperature points  
                endpoint = '/networks/local/objects/temp-object/streams/temp-stream/points'
                query = {
                    'points-value': Temp,
                    'points-at': t
                }
                response = requests.request('POST', base + endpoint, params=query, headers=header, timeout=120 )
                resp = json.loads( response.text )
                if resp['points-code'] == 200:
                    print( 'Update test-stream points: ok')
                else:
                    print( 'Update test-stream points: error')
                    print( response.text )        
                    
                    
                    
                time.sleep(1)
                
                print Pho
                print Temp
                
                time.sleep(1)

            else:
                #print dType
                print 'no new data'
                return [-1,-1]
            
             
        except: 
            print "read/post error" 
             
    # 100 ms delay 
    time.sleep(0.1) 
    return 


# Run continuously forever
# with a delay between calls
def delayed_loop():
    try:
        print "Delayed Loop"
        #every 5 seconds, check the server with get request
        #and send value to arduino for LED actuation
        query = {}
        endpoint = '/networks/local/objects/result-object/streams/result-stream/points'
        # Form and send request. Set timeout to 2 minutes. Receive response.
        response = requests.request('GET', base + endpoint, params=query, headers=header, timeout=120 )
        print response
        # Text is JSON string. Convert to Python dictionary/list
        resp = json.loads( response.text )
        print resp
        hLev = resp['points'][0]['value']
        print hLev
        #converts health level to an 8 bit string to be read by arduino and sends
        hLevSend = str(hLev)
        ser.write(hLevSend.encode("utf-8"))
    except:
        print "no health level to send"
    
    #return
# Run once at the end 
def close():
    try: 
        print "Close Serial Port" 
        #ser.close() 
    except: 
        print "Close Error"
    


###### MAIN function ##########
  
def main():
    # Call setup function
    setup()
    # Set start time
    nextLoop = time.time()
    while(True):
        # Try loop() and delayed_loop()
        try:
            data = loop()
            if time.time() > nextLoop:
                # If next loop time has passed...
                nextLoop = time.time() + delay
                delayed_loop()
                print ("LED brightness updated")
            else:
                print ("LED awaiting instructions")
        except KeyboardInterrupt:
            # If user enters "Ctrl + C", break while loop
            break
        except:
            # Catch all errors
            print "Unexpected error."
    # Call close function
    close()

# Run the program
main()
